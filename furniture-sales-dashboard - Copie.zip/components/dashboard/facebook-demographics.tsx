"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Users } from "lucide-react"

const demographicsData = [
  { age: "13-17", male: 2, female: 3 },
  { age: "18-24", male: 18, female: 22 },
  { age: "25-34", male: 25, female: 28 },
  { age: "35-44", male: 15, female: 12 },
  { age: "45-54", male: 8, female: 6 },
  { age: "55-64", male: 4, female: 3 },
  { age: "65+", male: 2, female: 2 },
]

export function FacebookDemographics() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#1877f2]/10 flex items-center justify-center">
            <Users className="h-4 w-4 text-[#1877f2]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Facebook Demographics</h3>
            <p className="text-xs text-muted-foreground">Age & Gender Distribution</p>
          </div>
        </div>
      </div>
      <div className="h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={demographicsData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis type="number" stroke="#666" fontSize={10} />
            <YAxis dataKey="age" type="category" stroke="#666" fontSize={10} width={40} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1a1a",
                border: "1px solid #333",
                borderRadius: "8px",
              }}
            />
            <Bar dataKey="male" fill="#00d4ff" radius={[0, 4, 4, 0]} name="Male" />
            <Bar dataKey="female" fill="#ff6b9d" radius={[0, 4, 4, 0]} name="Female" />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
