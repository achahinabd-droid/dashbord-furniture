"use client"
import { Users } from "lucide-react"
import { driversData, topSales, formatDZD } from "@/lib/sales-data"

const acquisitionData = [
  { name: driversData[0].name, nameEn: driversData[0].nameEn, value: driversData[0].revenue, color: "#00d4ff" },
  { name: driversData[1].name, nameEn: driversData[1].nameEn, value: driversData[1].revenue, color: "#00ff88" },
]

export function CustomerAcquisitionChart() {
  return (
    <div className="widget h-full">
      <div className="widget-header">
        <div className="w-8 h-8 rounded-lg bg-[#c084fc]/10 flex items-center justify-center">
          <Users className="h-4 w-4 text-[#c084fc]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">أداء السائقين</h3>
          <p className="text-xs text-muted-foreground">Driver Performance 2025</p>
        </div>
      </div>
      <div className="p-4">
        <div className="grid grid-cols-2 gap-4 mb-4">
          {driversData.map((driver, index) => (
            <div key={driver.nameEn} className="bg-[#0a0a0a]/50 rounded-lg p-3 border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: index === 0 ? "#00d4ff" : "#00ff88" }}
                />
                <span className="text-sm font-medium text-white">{driver.name}</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div>
                  <div className="text-lg font-bold" style={{ color: index === 0 ? "#00d4ff" : "#00ff88" }}>
                    {driver.sales}
                  </div>
                  <div className="text-[10px] text-muted-foreground">مبيعات</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-white">{driver.deliveries}</div>
                  <div className="text-[10px] text-muted-foreground">توصيل</div>
                </div>
                <div>
                  <div className="text-sm font-bold text-[#ffd93d]">{formatDZD(driver.revenue)}</div>
                  <div className="text-[10px] text-muted-foreground">إيرادات</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-4">
          <h4 className="text-xs font-medium text-muted-foreground mb-2">أكبر المبيعات - Top Sales</h4>
          <div className="space-y-1.5 max-h-[120px] overflow-y-auto">
            {topSales.slice(0, 5).map((sale, index) => (
              <div
                key={index}
                className="flex items-center justify-between text-xs bg-[#0a0a0a]/30 rounded px-2 py-1.5"
              >
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">{sale.date}</span>
                  <span className="text-white">{sale.customer}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground">{sale.wilaya}</span>
                  <span className="font-semibold text-[#00ff88]">{formatDZD(sale.total)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
