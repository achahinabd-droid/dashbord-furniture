import { Sofa, Bell, Settings, User } from "lucide-react"

export function DashboardHeader() {
  return (
    <header className="flex items-center justify-between mb-3">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2 px-4 py-2.5 widget rounded-lg">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#00d4ff] to-[#0088ff] flex items-center justify-center">
            <Sofa className="h-4 w-4 text-black" />
          </div>
          <div>
            <span className="text-lg font-bold text-white neon-text">Achab & Sons</span>
            <span className="text-xs text-muted-foreground block">Command Center</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-1 px-3 py-1 rounded-full bg-[#00ff88]/10 border border-[#00ff88]/30">
          <span className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse" />
          <span className="text-xs text-[#00ff88]">Live</span>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button className="p-2 rounded-lg hover:bg-white/5 text-muted-foreground hover:text-[#00d4ff] transition-colors">
          <Bell className="h-5 w-5" />
        </button>
        <button className="p-2 rounded-lg hover:bg-white/5 text-muted-foreground hover:text-[#00d4ff] transition-colors">
          <Settings className="h-5 w-5" />
        </button>
        <button className="p-2 rounded-lg hover:bg-white/5 text-muted-foreground hover:text-[#00d4ff] transition-colors">
          <User className="h-5 w-5" />
        </button>
      </div>
    </header>
  )
}
