"use client"

import { Facebook, Youtube, Instagram, Twitter, Linkedin } from "lucide-react"

const socialData = [
  { name: "Facebook", value: 26472, icon: Facebook, color: "#1877f2" },
  { name: "YouTube", value: 13911, icon: Youtube, color: "#ff0000" },
  { name: "Instagram", value: 6524, icon: Instagram, color: "#e4405f" },
  { name: "Twitter", value: 45322, icon: Twitter, color: "#1da1f2" },
  { name: "LinkedIn", value: 1765, icon: Linkedin, color: "#0a66c2" },
]

export function SocialFollowers() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2 h-2 rounded-full bg-[#00d4ff]" />
        <h3 className="text-sm font-semibold text-white">Social Media Followers</h3>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {socialData.map((social) => (
          <div
            key={social.name}
            className="p-3 rounded-lg text-center transition-all duration-300 hover:scale-105"
            style={{ backgroundColor: `${social.color}15`, border: `1px solid ${social.color}30` }}
          >
            <social.icon className="h-6 w-6 mx-auto mb-2" style={{ color: social.color }} />
            <div className="text-lg font-bold text-white">{social.value.toLocaleString()}</div>
            <div className="text-xs text-muted-foreground">{social.name}</div>
          </div>
        ))}
      </div>
    </div>
  )
}
