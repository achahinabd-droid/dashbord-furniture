"use client"

import { Play, Users, Target } from "lucide-react"

export function WistiaStats() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-8 h-8 rounded-lg bg-[#00d4ff]/10 flex items-center justify-center">
          <Play className="h-4 w-4 text-[#00d4ff]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">Video Stats</h3>
          <p className="text-xs text-muted-foreground">Wistia Analytics</p>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-3">
        <div className="text-center p-2 rounded-lg bg-[#00d4ff]/5">
          <Play className="h-4 w-4 mx-auto text-[#00d4ff] mb-1" />
          <div className="text-xl font-bold text-white">563</div>
          <div className="text-[10px] text-muted-foreground">Plays</div>
        </div>
        <div className="text-center p-2 rounded-lg bg-[#00ff88]/5">
          <Users className="h-4 w-4 mx-auto text-[#00ff88] mb-1" />
          <div className="text-xl font-bold text-white">75%</div>
          <div className="text-[10px] text-muted-foreground">Engagement</div>
        </div>
        <div className="text-center p-2 rounded-lg bg-[#ffd93d]/5">
          <Target className="h-4 w-4 mx-auto text-[#ffd93d] mb-1" />
          <div className="text-xl font-bold text-white">49%</div>
          <div className="text-[10px] text-muted-foreground">Play Rate</div>
        </div>
      </div>
    </div>
  )
}
