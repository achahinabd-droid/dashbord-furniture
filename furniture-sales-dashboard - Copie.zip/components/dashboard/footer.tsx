import { Clock } from "lucide-react"

export function DashboardFooter() {
  return (
    <footer className="mt-3 flex flex-wrap justify-between items-center px-4 py-2 widget rounded-lg">
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-white">أثاث عشّاب و أبناءه</span>
        <span className="text-xs text-muted-foreground">|</span>
        <span className="text-xs text-muted-foreground">Achab & Sons Furniture</span>
      </div>
      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-1">
          <Clock className="h-3 w-3" />
          <span>Last updated: Just now</span>
        </div>
        <span className="hidden sm:inline">|</span>
        <span className="hidden sm:inline">Powered by v0</span>
      </div>
    </footer>
  )
}
