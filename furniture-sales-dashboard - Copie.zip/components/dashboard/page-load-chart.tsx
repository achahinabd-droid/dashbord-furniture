"use client"

import { Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ComposedChart } from "recharts"
import { Clock } from "lucide-react"

const loadTimeData = [
  { day: "Mon", load: 1200, response: 400 },
  { day: "Tue", load: 900, response: 350 },
  { day: "Wed", load: 1500, response: 470 },
  { day: "Thu", load: 1100, response: 380 },
  { day: "Fri", load: 950, response: 360 },
  { day: "Sat", load: 1300, response: 420 },
  { day: "Sun", load: 800, response: 300 },
]

export function PageLoadChart() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#00d4ff]/10 flex items-center justify-center">
            <Clock className="h-4 w-4 text-[#00d4ff]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Website - Page Load Time</h3>
            <p className="text-xs text-muted-foreground">Response time in ms</p>
          </div>
        </div>
        <div className="flex gap-3 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-[#00d4ff]" />
            <span className="text-muted-foreground">Load Time</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-2 h-2 rounded-full bg-[#00ff88]" />
            <span className="text-muted-foreground">Response</span>
          </div>
        </div>
      </div>
      <div className="h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={loadTimeData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="day" stroke="#666" fontSize={10} />
            <YAxis stroke="#666" fontSize={10} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1a1a",
                border: "1px solid #333",
                borderRadius: "8px",
              }}
            />
            <Bar dataKey="load" fill="#00d4ff" radius={[4, 4, 0, 0]} />
            <Line type="monotone" dataKey="response" stroke="#00ff88" strokeWidth={2} dot={{ fill: "#00ff88", r: 3 }} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
