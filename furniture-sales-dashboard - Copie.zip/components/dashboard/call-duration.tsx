"use client"

import { Phone } from "lucide-react"
import { LineChart, Line, ResponsiveContainer } from "recharts"

const callData = [{ value: 600 }, { value: 620 }, { value: 540 }, { value: 680 }, { value: 610 }]

export function CallDuration() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-lg bg-[#00ff88]/10 flex items-center justify-center">
          <Phone className="h-4 w-4 text-[#00ff88]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">Avg Call Duration</h3>
          <p className="text-xs text-muted-foreground">CallRail Today</p>
        </div>
      </div>
      <div className="flex items-end justify-between">
        <div className="text-3xl font-bold text-white">10:08</div>
        <div className="w-24 h-12">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={callData}>
              <Line type="monotone" dataKey="value" stroke="#00ff88" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}
