"use client"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Filter, Calendar, MapPin, Package, Users, Truck } from "lucide-react"

const allWilayas = [
  "All Wilayas",
  // Original 48 wilayas (1-48)
  "Adrar",
  "Chlef",
  "Laghouat",
  "Oum El Bouaghi",
  "Batna",
  "Béjaïa",
  "Biskra",
  "Béchar",
  "Blida",
  "Bouira",
  "Tamanrasset",
  "Tébessa",
  "Tlemcen",
  "Tiaret",
  "Tizi Ouzou",
  "Alger",
  "Djelfa",
  "Jijel",
  "Sétif",
  "Saïda",
  "Skikda",
  "Sidi Bel Abbès",
  "Annaba",
  "Guelma",
  "Constantine",
  "Médéa",
  "Mostaganem",
  "M'Sila",
  "Mascara",
  "Ouargla",
  "Oran",
  "El Bayadh",
  "Illizi",
  "Bordj Bou Arréridj",
  "Boumerdès",
  "El Tarf",
  "Tindouf",
  "Tissemsilt",
  "El Oued",
  "Khenchela",
  "Souk Ahras",
  "Tipaza",
  "Mila",
  "Aïn Defla",
  "Naâma",
  "Aïn Témouchent",
  "Ghardaïa",
  "Relizane",
  // New 10 wilayas added in 2019 (49-58)
  "Timimoun",
  "Bordj Badji Mokhtar",
  "Ouled Djellal",
  "Béni Abbès",
  "In Salah",
  "In Guezzam",
  "Touggourt",
  "Djanet",
  "El M'Ghair",
  "El Meniaa",
]

const filters = [
  {
    id: "product",
    label: "Product",
    icon: Package,
    options: ["All Products", "غرف نوم", "صالونات", "خزائن", "أطقم أطفال", "طاولات"],
  },
  {
    id: "wilaya",
    label: "Wilaya",
    icon: MapPin,
    options: allWilayas,
  },
  { id: "year", label: "Year", icon: Calendar, options: ["2024", "2023", "2022", "2021"] },
  {
    id: "month",
    label: "Month",
    icon: Calendar,
    options: ["All Months", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
  },
  { id: "customer", label: "Customer", icon: Users, options: ["All Types", "Retail", "Wholesale", "Corporate"] },
  {
    id: "delivery",
    label: "Delivery",
    icon: Truck,
    options: ["All Status", "Delivered", "In Transit", "Delayed", "Cancelled"],
  },
]

export function FiltersSection() {
  return (
    <div className="widget p-3 rounded-lg">
      <div className="flex items-center gap-2 mb-3">
        <Filter className="h-4 w-4 text-[#00d4ff]" />
        <span className="text-sm font-medium text-white">Filters</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {filters.map((filter) => (
          <Select key={filter.id} defaultValue={filter.options[0]}>
            <SelectTrigger className="h-8 px-3 text-xs bg-black/40 border-white/10 hover:border-[#00d4ff]/50 min-w-[120px] transition-colors">
              <filter.icon className="h-3 w-3 mr-1.5 text-muted-foreground" />
              <SelectValue placeholder={filter.label} />
            </SelectTrigger>
            <SelectContent className="bg-[#181818] border-white/10 max-h-[300px]">
              {filter.options.map((opt) => (
                <SelectItem key={opt} value={opt} className="text-xs hover:bg-[#00d4ff]/10">
                  {opt}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        ))}
      </div>
    </div>
  )
}
