"use client"

import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts"
import { Truck, CheckCircle, Clock, XCircle } from "lucide-react"
import { deliveryStats, formatDZD } from "@/lib/sales-data"

const total = deliveryStats.successful + deliveryStats.pending + deliveryStats.returned
const deliveryData = [
  {
    name: "تم التوصيل",
    nameEn: "Delivered",
    value: Math.round((deliveryStats.successful / total) * 100),
    color: "#00ff88",
    icon: CheckCircle,
  },
  {
    name: "قيد الانتظار",
    nameEn: "Pending",
    value: Math.round((deliveryStats.pending / total) * 100),
    color: "#ffd93d",
    icon: Clock,
  },
  {
    name: "مرتجع",
    nameEn: "Returned",
    value: Math.round((deliveryStats.returned / total) * 100),
    color: "#ff6b6b",
    icon: XCircle,
  },
]

const successRate = Math.round((deliveryStats.successful / total) * 100)

export function DeliveryPerformanceChart() {
  return (
    <div className="widget h-full">
      <div className="widget-header">
        <div className="w-8 h-8 rounded-lg bg-[#00d4ff]/10 flex items-center justify-center">
          <Truck className="h-4 w-4 text-[#00d4ff]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">التوصيل</h3>
          <p className="text-xs text-muted-foreground">Delivery Status</p>
        </div>
      </div>
      <div className="p-4">
        <div className="relative h-[120px] flex items-center justify-center">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={deliveryData}
                cx="50%"
                cy="50%"
                innerRadius={35}
                outerRadius={50}
                startAngle={90}
                endAngle={-270}
                paddingAngle={2}
                dataKey="value"
              >
                {deliveryData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-2xl font-bold text-[#00ff88]">{successRate}%</span>
            <span className="text-[10px] text-muted-foreground">نجاح</span>
          </div>
        </div>
        <div className="flex flex-col gap-1.5 mt-2">
          {deliveryData.map((item) => (
            <div key={item.nameEn} className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-xs text-muted-foreground flex-1">{item.name}</span>
              <span className="text-xs font-semibold text-white">{item.value}%</span>
            </div>
          ))}
        </div>
        <div className="mt-3 pt-3 border-t border-white/5 flex justify-between text-xs">
          <span className="text-muted-foreground">تكلفة التوصيل الإجمالية</span>
          <span className="font-semibold text-[#00d4ff]">{formatDZD(deliveryStats.totalCost)}</span>
        </div>
      </div>
    </div>
  )
}
