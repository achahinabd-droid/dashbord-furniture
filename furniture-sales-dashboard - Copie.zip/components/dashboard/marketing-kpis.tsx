"use client"

import { DollarSign, Activity, TrendingUp } from "lucide-react"

export function MarketingKPIs() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-2 h-2 rounded-full bg-[#ffd93d]" />
        <h3 className="text-sm font-semibold text-white">Marketing & Promotion</h3>
      </div>
      <div className="space-y-4">
        <div className="p-3 rounded-lg bg-[#ffd93d]/10 border border-[#ffd93d]/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-[#ffd93d]" />
              <span className="text-xs text-muted-foreground">Ad Spend</span>
            </div>
            <TrendingUp className="h-3 w-3 text-[#00ff88]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1">$16,839</div>
        </div>
        <div className="p-3 rounded-lg bg-[#c084fc]/10 border border-[#c084fc]/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-[#c084fc]" />
              <span className="text-xs text-muted-foreground">Session Traffic</span>
            </div>
            <TrendingUp className="h-3 w-3 text-[#00ff88]" />
          </div>
          <div className="text-2xl font-bold text-white mt-1">280,430</div>
        </div>
      </div>
    </div>
  )
}
