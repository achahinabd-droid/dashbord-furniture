"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { PieChartIcon } from "lucide-react"
import { productDistribution } from "@/lib/sales-data"

const productData = [
  {
    name: productDistribution[0].name,
    nameEn: productDistribution[0].nameEn,
    value: productDistribution[0].percentage,
    color: "#00d4ff",
  },
  {
    name: productDistribution[1].name,
    nameEn: productDistribution[1].nameEn,
    value: productDistribution[1].percentage,
    color: "#00ff88",
  },
  {
    name: productDistribution[2].name,
    nameEn: productDistribution[2].nameEn,
    value: productDistribution[2].percentage,
    color: "#ffd93d",
  },
  {
    name: productDistribution[3].name,
    nameEn: productDistribution[3].nameEn,
    value: productDistribution[3].percentage,
    color: "#c084fc",
  },
  {
    name: productDistribution[4].name,
    nameEn: productDistribution[4].nameEn,
    value: productDistribution[4].percentage,
    color: "#ff6b6b",
  },
  {
    name: "أخرى",
    nameEn: "Others",
    value: 100 - productDistribution.slice(0, 5).reduce((a, b) => a + b.percentage, 0),
    color: "#64748b",
  },
]

export function ProductDistributionChart() {
  return (
    <div className="widget h-full">
      <div className="widget-header">
        <div className="w-8 h-8 rounded-lg bg-[#c084fc]/10 flex items-center justify-center">
          <PieChartIcon className="h-4 w-4 text-[#c084fc]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">توزيع المنتجات</h3>
          <p className="text-xs text-muted-foreground">Product Distribution</p>
        </div>
      </div>
      <div className="p-4 flex items-center gap-4">
        <div className="h-[160px] w-[140px]">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={productData}
                cx="50%"
                cy="50%"
                innerRadius={35}
                outerRadius={55}
                paddingAngle={2}
                dataKey="value"
              >
                {productData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(18, 18, 18, 0.95)",
                  border: "1px solid rgba(0, 212, 255, 0.3)",
                  borderRadius: "8px",
                  color: "#e5e7eb",
                }}
                formatter={(value: number, name: string, props: any) => [`${value.toFixed(1)}%`, props.payload.name]}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="flex flex-col gap-1.5">
          {productData.map((item) => (
            <div key={item.nameEn} className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
              <span className="text-xs text-muted-foreground">{item.name}</span>
              <span className="text-xs font-semibold text-white ml-auto">{item.value.toFixed(1)}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
