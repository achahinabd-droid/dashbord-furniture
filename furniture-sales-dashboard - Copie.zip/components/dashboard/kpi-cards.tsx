"use client"

import { DollarSign, ShoppingCart, Package, Users, Truck, TrendingUp, TrendingDown, UserCheck } from "lucide-react"
import { salesSummary, formatDZD } from "@/lib/sales-data"

const kpiData = [
  {
    title: "إجمالي الإيرادات",
    titleEn: "Total Revenue",
    value: formatDZD(salesSummary.totalRevenue),
    change: "+18.5%",
    trend: "up",
    icon: DollarSign,
    color: "#00d4ff",
  },
  {
    title: "عمليات البيع",
    titleEn: "Total Sales",
    value: salesSummary.totalSales.toLocaleString(),
    change: "+12.3%",
    trend: "up",
    icon: ShoppingCart,
    color: "#00ff88",
  },
  {
    title: "الوحدات المباعة",
    titleEn: "Units Sold",
    value: salesSummary.totalUnits.toLocaleString(),
    change: "+15.7%",
    trend: "up",
    icon: Package,
    color: "#ffd93d",
  },
  {
    title: "العملاء",
    titleEn: "Customers",
    value: salesSummary.totalCustomers.toLocaleString(),
    change: "+9.2%",
    trend: "up",
    icon: Users,
    color: "#c084fc",
  },
  {
    title: "نسبة التوصيل",
    titleEn: "Delivery Rate",
    value: `${salesSummary.deliveryRate}%`,
    change: "+1.4%",
    trend: "up",
    icon: Truck,
    color: "#00d4ff",
  },
  {
    title: "متوسط الطلب",
    titleEn: "Avg. Order",
    value: formatDZD(salesSummary.averageOrderValue),
    change: "+5.8%",
    trend: "up",
    icon: UserCheck,
    color: "#00ff88",
  },
]

export function KPICards() {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-2">
      {kpiData.map((kpi) => (
        <div key={kpi.titleEn} className="widget p-3 rounded-lg group hover:widget-glow transition-all duration-300">
          <div className="flex items-start justify-between mb-2">
            <div
              className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ backgroundColor: `${kpi.color}15` }}
            >
              <kpi.icon className="h-4 w-4" style={{ color: kpi.color }} />
            </div>
            <div className={`flex items-center gap-0.5 text-xs ${kpi.trend === "up" ? "trend-up" : "trend-down"}`}>
              {kpi.trend === "up" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
              <span>{kpi.change}</span>
            </div>
          </div>
          <div className="text-xl font-bold text-white" style={{ textShadow: `0 0 20px ${kpi.color}30` }}>
            {kpi.value}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">{kpi.title}</div>
          <div className="text-[10px] text-muted-foreground/60">{kpi.titleEn}</div>
        </div>
      ))}
    </div>
  )
}
