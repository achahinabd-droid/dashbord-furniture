"use client"

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Package, TrendingUp } from "lucide-react"
import { monthlySalesTrend } from "@/lib/sales-data"

const unitsData = monthlySalesTrend.map((item) => ({
  month: item.monthEn,
  units: item.units,
  sales: item.sales,
}))

export function UnitsSoldChart() {
  return (
    <div className="widget h-full">
      <div className="widget-header">
        <div className="w-8 h-8 rounded-lg bg-[#00ff88]/10 flex items-center justify-center">
          <Package className="h-4 w-4 text-[#00ff88]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">الوحدات المباعة</h3>
          <p className="text-xs text-muted-foreground">Units Sold 2025</p>
        </div>
        <div className="ml-auto flex items-center gap-1 text-xs text-[#00ff88]">
          <TrendingUp className="h-3 w-3" />
          <span>+15.7%</span>
        </div>
      </div>
      <div className="p-4 h-[200px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={unitsData}>
            <defs>
              <linearGradient id="unitsGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#00ff88" stopOpacity={0.3} />
                <stop offset="95%" stopColor="#00ff88" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis dataKey="month" stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(18, 18, 18, 0.95)",
                border: "1px solid rgba(0, 255, 136, 0.3)",
                borderRadius: "8px",
                color: "#e5e7eb",
              }}
              formatter={(value: number, name: string) => [
                `${value} ${name === "units" ? "وحدة" : "عملية"}`,
                name === "units" ? "Units" : "Sales",
              ]}
            />
            <Area type="monotone" dataKey="units" stroke="#00ff88" strokeWidth={2} fill="url(#unitsGradient)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
