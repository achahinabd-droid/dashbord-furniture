"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts"
import { Star, TrendingUp } from "lucide-react"
import { topProducts, formatDZD } from "@/lib/sales-data"

const satisfactionData = topProducts.slice(0, 5).map((product, index) => ({
  name: product.name.length > 20 ? product.name.substring(0, 20) + "..." : product.name,
  sold: product.sold,
  price: product.price,
  color: ["#00d4ff", "#00ff88", "#ffd93d", "#c084fc", "#ff6b6b"][index],
}))

export function CustomerSatisfactionChart() {
  return (
    <div className="widget h-full">
      <div className="widget-header">
        <div className="w-8 h-8 rounded-lg bg-[#ffd93d]/10 flex items-center justify-center">
          <Star className="h-4 w-4 text-[#ffd93d]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">أفضل المنتجات</h3>
          <p className="text-xs text-muted-foreground">Top Selling Products</p>
        </div>
        <div className="ml-auto flex items-center gap-1 text-xs text-[#00ff88]">
          <TrendingUp className="h-3 w-3" />
          <span>Top 5</span>
        </div>
      </div>
      <div className="p-4 h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={satisfactionData} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" horizontal={false} />
            <XAxis type="number" stroke="#6b7280" fontSize={10} tickLine={false} axisLine={false} />
            <YAxis
              dataKey="name"
              type="category"
              stroke="#6b7280"
              fontSize={9}
              tickLine={false}
              axisLine={false}
              width={100}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: "rgba(18, 18, 18, 0.95)",
                border: "1px solid rgba(255, 217, 61, 0.3)",
                borderRadius: "8px",
                color: "#e5e7eb",
              }}
              formatter={(value: number, name: string, props: any) => [
                `${value} وحدة - ${formatDZD(props.payload.price)}`,
                "المبيعات",
              ]}
            />
            <Bar dataKey="sold" radius={[0, 4, 4, 0]}>
              {satisfactionData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
