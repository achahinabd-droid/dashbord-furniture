"use client"

import { Calculator, TrendingDown } from "lucide-react"

export function CACMetric() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-lg bg-[#00ff88]/10 flex items-center justify-center">
          <Calculator className="h-4 w-4 text-[#00ff88]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">CAC</h3>
          <p className="text-xs text-muted-foreground">QuickBooks & Salesforce (30 Days)</p>
        </div>
      </div>
      <div className="flex items-end justify-between mt-4">
        <div>
          <div className="text-3xl font-bold text-white">$15,085</div>
          <div className="flex items-center gap-1 mt-1">
            <TrendingDown className="h-3 w-3 text-[#00ff88]" />
            <span className="text-sm text-[#00ff88]">-29.99%</span>
          </div>
        </div>
        <div className="text-xs text-muted-foreground">Customer Acquisition Cost</div>
      </div>
    </div>
  )
}
