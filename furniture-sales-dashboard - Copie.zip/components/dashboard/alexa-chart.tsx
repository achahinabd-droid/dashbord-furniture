"use client"

import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { Eye } from "lucide-react"

const alexaData = [
  { date: "Apr 1", views1: 2.4, views2: 1.8 },
  { date: "Apr 5", views1: 2.1, views2: 2.2 },
  { date: "Apr 10", views1: 2.8, views2: 1.9 },
  { date: "Apr 15", views1: 2.5, views2: 2.4 },
  { date: "Apr 20", views1: 3.1, views2: 2.1 },
  { date: "Apr 26", views1: 2.9, views2: 2.6 },
]

export function AlexaChart() {
  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-[#c084fc]/10 flex items-center justify-center">
            <Eye className="h-4 w-4 text-[#c084fc]" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">Alexa Page Views per User</h3>
            <p className="text-xs text-muted-foreground">Last 30 days</p>
          </div>
        </div>
      </div>
      <div className="h-[160px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={alexaData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#333" />
            <XAxis dataKey="date" stroke="#666" fontSize={10} />
            <YAxis stroke="#666" fontSize={10} />
            <Tooltip
              contentStyle={{
                backgroundColor: "#1a1a1a",
                border: "1px solid #333",
                borderRadius: "8px",
              }}
            />
            <Line type="monotone" dataKey="views1" stroke="#c084fc" strokeWidth={2} dot={{ fill: "#c084fc", r: 3 }} />
            <Line type="monotone" dataKey="views2" stroke="#00d4ff" strokeWidth={2} dot={{ fill: "#00d4ff", r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
