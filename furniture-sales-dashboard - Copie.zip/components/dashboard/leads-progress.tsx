"use client"

import { Target } from "lucide-react"

export function LeadsProgress() {
  const current = 10753
  const goal = 12000
  const percentage = Math.round((current / goal) * 100)

  return (
    <div className="widget p-4 rounded-lg h-full">
      <div className="flex items-center gap-2 mb-3">
        <div className="w-8 h-8 rounded-lg bg-[#ffd93d]/10 flex items-center justify-center">
          <Target className="h-4 w-4 text-[#ffd93d]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">Leads This Month</h3>
          <p className="text-xs text-muted-foreground">Goal: {goal.toLocaleString()}</p>
        </div>
      </div>
      <div className="mt-4">
        <div className="flex justify-between text-sm mb-2">
          <span className="text-2xl font-bold text-white">{current.toLocaleString()}</span>
          <span className="text-[#ffd93d]">{percentage}%</span>
        </div>
        <div className="h-3 bg-[#1a1a1a] rounded-full overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${percentage}%`,
              background: "linear-gradient(90deg, #ffd93d, #00ff88)",
            }}
          />
        </div>
      </div>
    </div>
  )
}
