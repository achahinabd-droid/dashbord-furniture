"use client"

import { useState } from "react"
import { MapPin } from "lucide-react"
import { salesByWilaya as realSalesData, formatDZD } from "@/lib/sales-data"

const wilayaMapping: Record<string, string> = {
  "سوق أهراس": "Souk Ahras",
  الطارف: "El Tarf",
  قسنطينة: "Constantine",
  خنشلة: "Khenchela",
  "أم البواقي": "Oum El Bouaghi",
  تبسة: "Tébessa",
  الجزائر: "Alger",
  تيبازة: "Tipaza",
  وهران: "Oran",
  قالمة: "Guelma",
  البليدة: "Blida",
  عنابة: "Annaba",
  سكيكدة: "Skikda",
  جيجل: "Jijel",
  باتنة: "Batna",
  تلمسان: "Tlemcen",
  المدية: "Médéa",
  سطيف: "Sétif",
  البويرة: "Bouira",
  بسكرة: "Biskra",
  ميلة: "Mila",
  بجاية: "Béjaïa",
  "برج بوعريريج": "Bordj Bou Arréridj",
  معسكر: "Mascara",
  مستغانم: "Mostaganem",
  تيارت: "Tiaret",
  سعيدة: "Saïda",
  "تيزي وزو": "Tizi Ouzou",
  غليزان: "Relizane",
  الشلف: "Chlef",
  "عين الدفلى": "Aïn Defla",
  "عين تموشنت": "Aïn Témouchent",
  "سيدي بلعباس": "Sidi Bel Abbès",
  تقرت: "Touggourt",
  الوادي: "El Oued",
  بومرداس: "Boumerdès",
}

// Build sales data from real CSV data
const salesByWilaya: Record<string, number> = {}
Object.entries(realSalesData).forEach(([arabicName, data]) => {
  const frenchName = wilayaMapping[arabicName]
  if (frenchName) {
    salesByWilaya[frenchName] = data.revenue
  }
})

// Add default values for wilayas without sales
const allWilayas = [
  "Adrar",
  "Chlef",
  "Laghouat",
  "Oum El Bouaghi",
  "Batna",
  "Béjaïa",
  "Biskra",
  "Béchar",
  "Blida",
  "Bouira",
  "Tamanrasset",
  "Tébessa",
  "Tlemcen",
  "Tiaret",
  "Tizi Ouzou",
  "Alger",
  "Djelfa",
  "Jijel",
  "Sétif",
  "Saïda",
  "Skikda",
  "Sidi Bel Abbès",
  "Annaba",
  "Guelma",
  "Constantine",
  "Médéa",
  "Mostaganem",
  "M'Sila",
  "Mascara",
  "Ouargla",
  "Oran",
  "El Bayadh",
  "Illizi",
  "Bordj Bou Arréridj",
  "Boumerdès",
  "El Tarf",
  "Tindouf",
  "Tissemsilt",
  "El Oued",
  "Khenchela",
  "Souk Ahras",
  "Tipaza",
  "Mila",
  "Aïn Defla",
  "Naâma",
  "Aïn Témouchent",
  "Ghardaïa",
  "Relizane",
  "Timimoun",
  "Bordj Badji Mokhtar",
  "Ouled Djellal",
  "Béni Abbès",
  "In Salah",
  "In Guezzam",
  "Touggourt",
  "Djanet",
  "El M'Ghair",
  "El Meniaa",
]
allWilayas.forEach((w) => {
  if (!salesByWilaya[w]) salesByWilaya[w] = 0
})

const arabicNames: Record<string, string> = {
  Adrar: "أدرار",
  Chlef: "الشلف",
  Laghouat: "الأغواط",
  "Oum El Bouaghi": "أم البواقي",
  Batna: "باتنة",
  Béjaïa: "بجاية",
  Biskra: "بسكرة",
  Béchar: "بشار",
  Blida: "البليدة",
  Bouira: "البويرة",
  Tamanrasset: "تمنراست",
  Tébessa: "تبسة",
  Tlemcen: "تلمسان",
  Tiaret: "تيارت",
  "Tizi Ouzou": "تيزي وزو",
  Alger: "الجزائر",
  Djelfa: "الجلفة",
  Jijel: "جيجل",
  Sétif: "سطيف",
  Saïda: "سعيدة",
  Skikda: "سكيكدة",
  "Sidi Bel Abbès": "سيدي بلعباس",
  Annaba: "عنابة",
  Guelma: "قالمة",
  Constantine: "قسنطينة",
  Médéa: "المدية",
  Mostaganem: "مستغانم",
  "M'Sila": "المسيلة",
  Mascara: "معسكر",
  Ouargla: "ورقلة",
  Oran: "وهران",
  "El Bayadh": "البيض",
  Illizi: "إليزي",
  "Bordj Bou Arréridj": "برج بوعريريج",
  Boumerdès: "بومرداس",
  "El Tarf": "الطارف",
  Tindouf: "تندوف",
  Tissemsilt: "تيسمسيلت",
  "El Oued": "الوادي",
  Khenchela: "خنشلة",
  "Souk Ahras": "سوق أهراس",
  Tipaza: "تيبازة",
  Mila: "ميلة",
  "Aïn Defla": "عين الدفلى",
  Naâma: "النعامة",
  "Aïn Témouchent": "عين تموشنت",
  Ghardaïa: "غرداية",
  Relizane: "غليزان",
  Timimoun: "تيميمون",
  "Bordj Badji Mokhtar": "برج باجي مختار",
  "Ouled Djellal": "أولاد جلال",
  "Béni Abbès": "بني عباس",
  "In Salah": "عين صالح",
  "In Guezzam": "عين قزام",
  Touggourt: "تقرت",
  Djanet: "جانت",
  "El M'Ghair": "المغير",
  "El Meniaa": "المنيعة",
}

const wilayaPaths: { name: string; d: string; labelX: number; labelY: number }[] = [
  { name: "Tlemcen", d: "M15,28 L45,25 L50,40 L45,45 L15,42 Z", labelX: 32, labelY: 34 },
  { name: "Aïn Témouchent", d: "M45,22 L65,20 L70,32 L55,38 L45,35 Z", labelX: 56, labelY: 28 },
  { name: "Oran", d: "M60,15 L85,13 L90,25 L80,30 L62,28 Z", labelX: 75, labelY: 22 },
  { name: "Mostaganem", d: "M85,15 L105,14 L110,26 L95,30 L85,25 Z", labelX: 96, labelY: 22 },
  { name: "Chlef", d: "M105,18 L130,16 L138,28 L125,32 L110,28 Z", labelX: 120, labelY: 24 },
  { name: "Tipaza", d: "M138,18 L155,16 L160,26 L150,30 L140,28 Z", labelX: 148, labelY: 23 },
  { name: "Blida", d: "M150,22 L162,20 L168,30 L160,34 L152,30 Z", labelX: 158, labelY: 27 },
  { name: "Alger", d: "M160,12 L175,10 L180,20 L172,24 L162,20 Z", labelX: 170, labelY: 17 },
  { name: "Boumerdès", d: "M175,12 L192,10 L198,20 L188,24 L178,20 Z", labelX: 186, labelY: 17 },
  { name: "Tizi Ouzou", d: "M188,10 L210,8 L218,20 L205,26 L192,22 Z", labelX: 202, labelY: 16 },
  { name: "Béjaïa", d: "M208,8 L228,8 L235,18 L222,24 L212,20 Z", labelX: 220, labelY: 15 },
  { name: "Jijel", d: "M228,6 L248,6 L255,16 L242,20 L232,16 Z", labelX: 240, labelY: 12 },
  { name: "Skikda", d: "M248,5 L268,5 L275,14 L262,18 L252,14 Z", labelX: 260, labelY: 11 },
  { name: "Annaba", d: "M268,4 L285,4 L290,14 L280,18 L272,14 Z", labelX: 278, labelY: 10 },
  { name: "El Tarf", d: "M282,4 L298,5 L298,18 L290,18 L285,12 Z", labelX: 290, labelY: 11 },
  { name: "Sidi Bel Abbès", d: "M45,40 L70,38 L75,50 L65,55 L45,52 Z", labelX: 58, labelY: 45 },
  { name: "Mascara", d: "M75,35 L100,33 L105,45 L95,50 L75,50 Z", labelX: 88, labelY: 42 },
  { name: "Relizane", d: "M100,30 L120,28 L125,40 L105,45 L100,33 Z", labelX: 112, labelY: 36 },
  { name: "Tissemsilt", d: "M115,35 L130,33 L135,45 L125,50 L115,45 Z", labelX: 125, labelY: 42 },
  { name: "Aïn Defla", d: "M125,28 L145,26 L150,38 L140,42 L130,38 Z", labelX: 138, labelY: 34 },
  { name: "Médéa", d: "M145,35 L165,33 L175,45 L160,50 L145,45 Z", labelX: 158, labelY: 42 },
  { name: "Bouira", d: "M160,28 L180,26 L190,38 L175,42 L160,38 Z", labelX: 175, labelY: 34 },
  { name: "Bordj Bou Arréridj", d: "M180,28 L200,28 L205,38 L190,42 L180,38 Z", labelX: 192, labelY: 34 },
  { name: "Sétif", d: "M195,22 L225,20 L235,32 L220,38 L200,35 Z", labelX: 215, labelY: 28 },
  { name: "Mila", d: "M220,18 L240,18 L245,28 L235,32 L220,28 Z", labelX: 232, labelY: 24 },
  { name: "Constantine", d: "M240,15 L260,15 L265,25 L255,28 L245,25 Z", labelX: 252, labelY: 21 },
  { name: "Guelma", d: "M258,12 L275,12 L278,22 L268,25 L260,22 Z", labelX: 268, labelY: 18 },
  { name: "Souk Ahras", d: "M270,10 L290,12 L290,25 L278,22 L272,18 Z", labelX: 280, labelY: 18 },
  { name: "Oum El Bouaghi", d: "M230,28 L255,28 L255,35 L230,33 Z", labelX: 242, labelY: 31 },
  { name: "Khenchela", d: "M230,33 L255,35 L260,50 L245,50 Z", labelX: 245, labelY: 42 },
  { name: "Tébessa", d: "M255,35 L280,40 L280,70 L260,65 L255,50 Z", labelX: 268, labelY: 52 },
  { name: "Saïda", d: "M65,55 L85,50 L95,65 L80,75 L60,70 Z", labelX: 77, labelY: 62 },
  { name: "Tiaret", d: "M95,45 L125,42 L135,55 L120,75 L95,65 Z", labelX: 112, labelY: 58 },
  { name: "M'Sila", d: "M170,42 L195,40 L210,55 L185,55 L175,55 Z", labelX: 188, labelY: 48 },
  { name: "Batna", d: "M195,35 L230,33 L245,50 L230,70 L210,55 L195,40 Z", labelX: 218, labelY: 48 },
  { name: "Biskra", d: "M185,55 L220,55 L230,70 L210,85 L185,75 Z", labelX: 205, labelY: 68 },
  { name: "Naâma", d: "M50,75 L80,75 L70,95 L50,90 Z", labelX: 62, labelY: 83 },
  { name: "El Bayadh", d: "M80,75 L95,90 L120,90 L120,115 L90,115 L70,95 Z", labelX: 95, labelY: 95 },
  { name: "Laghouat", d: "M120,85 L145,75 L160,95 L150,95 L120,115 Z", labelX: 138, labelY: 92 },
  { name: "Djelfa", d: "M130,55 L175,55 L185,75 L160,95 L145,75 L130,80 Z", labelX: 155, labelY: 72 },
  { name: "Ghardaïa", d: "M140,115 L165,105 L175,130 L155,140 L140,130 Z", labelX: 155, labelY: 122 },
  { name: "El Meniaa", d: "M155,140 L175,130 L190,160 L165,170 Z", labelX: 172, labelY: 152 },
  { name: "Ouargla", d: "M175,105 L210,95 L230,110 L220,145 L190,140 L175,130 Z", labelX: 200, labelY: 120 },
  { name: "Touggourt", d: "M210,80 L240,75 L250,95 L230,110 L210,95 Z", labelX: 228, labelY: 90 },
  { name: "El M'Ghair", d: "M230,70 L260,72 L265,90 L250,95 L240,75 Z", labelX: 248, labelY: 82 },
  { name: "El Oued", d: "M240,55 L270,58 L275,75 L260,72 L240,70 Z", labelX: 255, labelY: 65 },
  { name: "Ouled Djellal", d: "M210,70 L240,70 L240,85 L210,85 Z", labelX: 225, labelY: 78 },
  { name: "Béchar", d: "M50,90 L90,90 L100,120 L75,140 L50,130 Z", labelX: 70, labelY: 115 },
  { name: "Béni Abbès", d: "M75,140 L100,120 L115,145 L95,165 L75,155 Z", labelX: 92, labelY: 150 },
  { name: "Timimoun", d: "M95,165 L115,145 L145,150 L150,180 L110,185 Z", labelX: 125, labelY: 165 },
  { name: "Adrar", d: "M110,185 L150,180 L175,200 L150,230 L100,220 Z", labelX: 135, labelY: 205 },
  { name: "Tindouf", d: "M10,145 L50,130 L55,180 L45,210 L10,195 Z", labelX: 30, labelY: 175 },
  { name: "Bordj Badji Mokhtar", d: "M45,210 L100,220 L110,255 L50,255 Z", labelX: 75, labelY: 235 },
  { name: "In Salah", d: "M150,180 L180,170 L195,200 L175,220 L150,210 Z", labelX: 170, labelY: 195 },
  { name: "Tamanrasset", d: "M150,220 L195,200 L220,230 L200,270 L140,270 Z", labelX: 175, labelY: 245 },
  { name: "In Guezzam", d: "M140,270 L200,270 L200,295 L140,295 Z", labelX: 170, labelY: 282 },
  { name: "Illizi", d: "M230,145 L265,130 L280,170 L270,210 L240,200 L230,165 Z", labelX: 255, labelY: 170 },
  { name: "Djanet", d: "M240,210 L280,200 L290,250 L250,260 Z", labelX: 265, labelY: 230 },
]

function getColor(sales: number): string {
  if (sales > 3000000) return "#00d4ff"
  if (sales > 2000000) return "#00a8cc"
  if (sales > 1000000) return "#0088aa"
  if (sales > 500000) return "#006688"
  if (sales > 100000) return "#004466"
  if (sales > 0) return "#003855"
  return "#002233"
}

export function AlgeriaMap() {
  const [hoveredWilaya, setHoveredWilaya] = useState<string | null>(null)
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 })

  const totalSales = Object.values(salesByWilaya).reduce((a, b) => a + b, 0)

  return (
    <div className="widget h-full">
      <div className="widget-header">
        <div className="w-8 h-8 rounded-lg bg-[#00d4ff]/10 flex items-center justify-center">
          <MapPin className="h-4 w-4 text-[#00d4ff]" />
        </div>
        <div>
          <h3 className="text-sm font-semibold text-white">خريطة المبيعات</h3>
          <p className="text-xs text-muted-foreground">Sales Map - Real Data 2025</p>
        </div>
        <div className="ml-auto text-right">
          <div className="text-lg font-bold text-[#00d4ff]">{formatDZD(totalSales)}</div>
          <div className="text-[10px] text-muted-foreground">إجمالي المبيعات</div>
        </div>
      </div>
      <div
        className="relative p-4"
        style={{ height: "calc(100% - 60px)" }}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect()
          setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top })
        }}
      >
        <svg viewBox="0 0 310 300" className="w-full h-full" preserveAspectRatio="xMidYMid meet">
          {wilayaPaths.map((wilaya) => {
            const sales = salesByWilaya[wilaya.name] || 0
            const isHovered = hoveredWilaya === wilaya.name
            const hasSales = sales > 0
            return (
              <g key={wilaya.name}>
                <path
                  d={wilaya.d}
                  fill={getColor(sales)}
                  stroke={isHovered ? "#00ff88" : hasSales ? "rgba(0, 212, 255, 0.5)" : "rgba(255,255,255,0.1)"}
                  strokeWidth={isHovered ? 2 : hasSales ? 1 : 0.5}
                  className="cursor-pointer transition-all duration-200"
                  style={{
                    filter: isHovered ? "brightness(1.5) drop-shadow(0 0 8px rgba(0, 255, 136, 0.6))" : "none",
                  }}
                  onMouseEnter={() => setHoveredWilaya(wilaya.name)}
                  onMouseLeave={() => setHoveredWilaya(null)}
                />
              </g>
            )
          })}
        </svg>

        {hoveredWilaya && (
          <div
            className="absolute z-20 pointer-events-none bg-[#181818]/95 border border-[#00d4ff]/40 rounded-lg px-3 py-2 shadow-xl backdrop-blur-sm"
            style={{
              left: Math.min(Math.max(mousePos.x + 15, 10), 200),
              top: Math.min(Math.max(mousePos.y - 10, 10), 280),
              boxShadow: "0 0 20px rgba(0, 212, 255, 0.2)",
            }}
          >
            <div className="text-sm font-semibold text-white">{hoveredWilaya}</div>
            <div className="text-xs text-muted-foreground" dir="rtl">
              {arabicNames[hoveredWilaya]}
            </div>
            <div className="text-sm font-bold text-[#00d4ff] mt-1">
              {salesByWilaya[hoveredWilaya] > 0 ? formatDZD(salesByWilaya[hoveredWilaya]) : "لا توجد مبيعات"}
            </div>
          </div>
        )}

        <div className="absolute bottom-2 left-2 bg-[#0a0a0a]/90 backdrop-blur-sm rounded-md p-2 border border-white/10">
          <div className="text-[10px] font-medium text-muted-foreground mb-1">كثافة المبيعات</div>
          <div className="flex gap-0.5">
            {["#002233", "#003855", "#004466", "#006688", "#0088aa", "#00d4ff"].map((color, i) => (
              <div key={i} className="w-4 h-3 rounded-sm" style={{ backgroundColor: color }} />
            ))}
          </div>
          <div className="flex justify-between text-[8px] text-muted-foreground mt-0.5">
            <span>منخفض</span>
            <span>مرتفع</span>
          </div>
        </div>
      </div>
    </div>
  )
}
