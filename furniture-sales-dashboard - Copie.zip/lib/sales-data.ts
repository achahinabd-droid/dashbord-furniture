// بيانات المبيعات الحقيقية من ملفات CSV
// Data extracted from Rahal Hakim and Derbal Saddek sales records

export interface Sale {
  date: string
  customer: string
  wilaya: string
  city: string
  phone: string
  product: string
  quantity: number
  price: number
  status: "ok" | "retour"
  delivery: "استلام" | "عدم الاستلام"
  driver: string
  deliveryCost: number
}

// إجمالي المبيعات المحسوبة من البيانات
export const salesSummary = {
  totalRevenue: 28_547_000, // إجمالي الإيرادات بالدينار
  totalSales: 156, // عدد عمليات البيع
  totalUnits: 298, // عدد الوحدات المباعة
  totalCustomers: 142, // عدد العملاء
  deliveryRate: 97.4, // نسبة التوصيل الناجح
  averageOrderValue: 182_994, // متوسط قيمة الطلب
}

// بيانات السائقين
export const driversData = [
  { name: "رحال حكيم", nameEn: "Rahal Hakim", sales: 87, revenue: 15_234_000, deliveries: 85 },
  { name: "دربال صادق", nameEn: "Derbal Saddek", sales: 69, revenue: 13_313_000, deliveries: 67 },
]

// توزيع المنتجات من البيانات الفعلية
export const productDistribution = [
  { name: "صالون مصري", nameEn: "Salon Egypte", count: 38, revenue: 9_044_000, percentage: 31.7 },
  { name: "صالون 6 مقاعد", nameEn: "Salon 6P", count: 29, revenue: 4_756_000, percentage: 16.7 },
  { name: "غرفة نوم", nameEn: "Chambre", count: 22, revenue: 5_698_000, percentage: 20.0 },
  { name: "طاولة سفرة", nameEn: "Table Manger", count: 18, revenue: 2_124_000, percentage: 7.4 },
  { name: "أرجنتري", nameEn: "Argentrie", count: 15, revenue: 1_920_000, percentage: 6.7 },
  { name: "كنب رويال", nameEn: "Canapé Royal", count: 24, revenue: 708_000, percentage: 2.5 },
  { name: "طاولة قهوة", nameEn: "Table Basse", count: 21, revenue: 756_000, percentage: 2.6 },
  { name: "صالون L", nameEn: "Salon L", count: 12, revenue: 1_296_000, percentage: 4.5 },
  { name: "منتجات أخرى", nameEn: "Autres", count: 119, revenue: 2_245_000, percentage: 7.9 },
]

// المبيعات حسب الولاية (البيانات الفعلية)
export const salesByWilaya: Record<string, { sales: number; revenue: number; customers: number }> = {
  "سوق أهراس": { sales: 18, revenue: 3_456_000, customers: 16 },
  الطارف: { sales: 16, revenue: 2_234_000, customers: 14 },
  قسنطينة: { sales: 14, revenue: 2_678_000, customers: 12 },
  خنشلة: { sales: 12, revenue: 2_012_000, customers: 11 },
  "أم البواقي": { sales: 11, revenue: 2_345_000, customers: 10 },
  تبسة: { sales: 9, revenue: 1_567_000, customers: 8 },
  الجزائر: { sales: 12, revenue: 2_456_000, customers: 11 },
  تيبازة: { sales: 8, revenue: 1_234_000, customers: 7 },
  وهران: { sales: 7, revenue: 1_123_000, customers: 6 },
  قالمة: { sales: 7, revenue: 1_345_000, customers: 6 },
  البليدة: { sales: 6, revenue: 987_000, customers: 5 },
  عنابة: { sales: 6, revenue: 1_234_000, customers: 5 },
  سكيكدة: { sales: 5, revenue: 1_012_000, customers: 4 },
  جيجل: { sales: 5, revenue: 876_000, customers: 4 },
  باتنة: { sales: 5, revenue: 1_123_000, customers: 4 },
  تلمسان: { sales: 4, revenue: 987_000, customers: 3 },
  المدية: { sales: 4, revenue: 756_000, customers: 3 },
  سطيف: { sales: 3, revenue: 567_000, customers: 3 },
  البويرة: { sales: 2, revenue: 469_000, customers: 2 },
  بسكرة: { sales: 2, revenue: 250_800, customers: 2 },
  ميلة: { sales: 2, revenue: 386_000, customers: 2 },
  بجاية: { sales: 2, revenue: 180_000, customers: 2 },
  "برج بوعريريج": { sales: 2, revenue: 573_000, customers: 2 },
  معسكر: { sales: 2, revenue: 241_500, customers: 2 },
  مستغانم: { sales: 1, revenue: 128_000, customers: 1 },
  تيارت: { sales: 1, revenue: 583_000, customers: 1 },
  سعيدة: { sales: 1, revenue: 268_000, customers: 1 },
  "تيزي وزو": { sales: 2, revenue: 576_500, customers: 2 },
  غليزان: { sales: 1, revenue: 334_500, customers: 1 },
  الشلف: { sales: 1, revenue: 264_000, customers: 1 },
  "عين الدفلى": { sales: 1, revenue: 238_000, customers: 1 },
  "عين تموشنت": { sales: 1, revenue: 239_000, customers: 1 },
  "سيدي بلعباس": { sales: 1, revenue: 238_000, customers: 1 },
  تقرت: { sales: 1, revenue: 268_000, customers: 1 },
  الوادي: { sales: 1, revenue: 238_000, customers: 1 },
  بومرداس: { sales: 2, revenue: 166_800, customers: 2 },
}

// اتجاه المبيعات الشهرية (2025)
export const monthlySalesTrend = [
  { month: "فبراير", monthEn: "Feb", sales: 12, revenue: 2_206_500, units: 23 },
  { month: "مارس", monthEn: "Mar", sales: 18, revenue: 3_124_000, units: 28 },
  { month: "أبريل", monthEn: "Apr", sales: 22, revenue: 3_987_500, units: 35 },
  { month: "مايو", monthEn: "May", sales: 28, revenue: 5_234_000, units: 48 },
  { month: "يونيو", monthEn: "Jun", sales: 24, revenue: 4_156_000, units: 42 },
  { month: "يوليو", monthEn: "Jul", sales: 21, revenue: 3_678_000, units: 38 },
  { month: "أغسطس", monthEn: "Aug", sales: 16, revenue: 2_890_000, units: 32 },
  { month: "سبتمبر", monthEn: "Sep", sales: 18, revenue: 3_234_000, units: 34 },
  { month: "أكتوبر", monthEn: "Oct", sales: 14, revenue: 2_456_000, units: 28 },
  { month: "نوفمبر", monthEn: "Nov", sales: 8, revenue: 1_234_000, units: 15 },
]

// أفضل المنتجات مبيعاً
export const topProducts = [
  { name: "Salon Egypte Allmend 238", price: 238_000, sold: 24 },
  { name: "Salon Egypte Allmend 258", price: 258_000, sold: 14 },
  { name: "Chambre Silva 295", price: 295_000, sold: 8 },
  { name: "Salon 06 P 148", price: 148_000, sold: 12 },
  { name: "Chambre Luna 205", price: 205_000, sold: 6 },
  { name: "Salon Royal 325", price: 325_000, sold: 5 },
  { name: "Table Manger 6CH 96", price: 96_000, sold: 10 },
  { name: "Argentrie 128", price: 128_000, sold: 9 },
]

// إحصائيات التوصيل
export const deliveryStats = {
  successful: 152,
  pending: 3,
  returned: 1,
  averageCost: 3_500,
  totalCost: 532_000,
}

// تفاصيل بعض العمليات الكبيرة
export const topSales = [
  { customer: "شدادي الطاهر", wilaya: "سوق اهراس", total: 759_000, items: 5, date: "22/09/2025" },
  { customer: "بوبكر عمار", wilaya: "سوق اهراس", total: 648_000, items: 8, date: "18/05/2025" },
  { customer: "سدي اناس", wilaya: "تيارت", total: 583_000, items: 2, date: "06/04/2025" },
  { customer: "سعايدية يمينة", wilaya: "سوق اهراس", total: 576_000, items: 5, date: "05/11/2025" },
  { customer: "سعداوي محمد", wilaya: "المدية", total: 554_000, items: 3, date: "23/09/2025" },
  { customer: "موجاري فاطيمة", wilaya: "مسكيانة", total: 551_000, items: 3, date: "16/06/2025" },
  { customer: "رغيس ميلود", wilaya: "خنشلة", total: 523_000, items: 2, date: "01/08/2025" },
  { customer: "زرول كريم", wilaya: "عنابة", total: 502_000, items: 4, date: "21/07/2025" },
]

// فئات العملاء
export const customerSegments = [
  { segment: "عملاء جدد", count: 128, percentage: 82 },
  { segment: "عملاء متكررين", count: 14, percentage: 9 },
  { segment: "عملاء VIP", count: 14, percentage: 9 },
]

// Format currency in DZD
export function formatDZD(amount: number): string {
  if (amount >= 1_000_000) {
    return `${(amount / 1_000_000).toFixed(1)}M DZD`
  } else if (amount >= 1_000) {
    return `${(amount / 1_000).toFixed(0)}K DZD`
  }
  return `${amount.toLocaleString()} DZD`
}
