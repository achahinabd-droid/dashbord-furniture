import { DashboardHeader } from "@/components/dashboard/header"
import { KPICards } from "@/components/dashboard/kpi-cards"
import { FiltersSection } from "@/components/dashboard/filters-section"
import { SalesTrendChart } from "@/components/dashboard/sales-trend-chart"
import { UnitsSoldChart } from "@/components/dashboard/units-sold-chart"
import { ProductDistributionChart } from "@/components/dashboard/product-distribution-chart"
import { CustomerSatisfactionChart } from "@/components/dashboard/customer-satisfaction-chart"
import { DeliveryPerformanceChart } from "@/components/dashboard/delivery-performance-chart"
import { CustomerAcquisitionChart } from "@/components/dashboard/customer-acquisition-chart"
import { AlgeriaMap } from "@/components/dashboard/algeria-map"
import { DashboardFooter } from "@/components/dashboard/footer"
import { SocialFollowers } from "@/components/dashboard/social-followers"
import { PageLoadChart } from "@/components/dashboard/page-load-chart"
import { MarketingKPIs } from "@/components/dashboard/marketing-kpis"
import { WistiaStats } from "@/components/dashboard/wistia-stats"
import { CallDuration } from "@/components/dashboard/call-duration"
import { AlexaChart } from "@/components/dashboard/alexa-chart"
import { CACMetric } from "@/components/dashboard/cac-metric"
import { LeadsProgress } from "@/components/dashboard/leads-progress"
import { FacebookDemographics } from "@/components/dashboard/facebook-demographics"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-[#0a0a0a] p-3 md:p-4">
      <DashboardHeader />

      {/* KPI Row */}
      <KPICards />

      {/* Filters Row */}
      <div className="mt-3">
        <FiltersSection />
      </div>

      <div className="grid grid-cols-12 gap-3 mt-3">
        {/* Row 1: Social + Page Load + Marketing KPIs */}
        <div className="col-span-12 lg:col-span-4">
          <SocialFollowers />
        </div>
        <div className="col-span-12 lg:col-span-5">
          <PageLoadChart />
        </div>
        <div className="col-span-12 lg:col-span-3">
          <MarketingKPIs />
        </div>

        {/* Row 2: Wistia + Call + Alexa */}
        <div className="col-span-12 md:col-span-4">
          <WistiaStats />
        </div>
        <div className="col-span-12 md:col-span-3">
          <CallDuration />
        </div>
        <div className="col-span-12 md:col-span-5">
          <AlexaChart />
        </div>

        {/* Row 3: Algeria Map + CAC + Leads */}
        <div className="col-span-12 lg:col-span-6 lg:row-span-2">
          <AlgeriaMap />
        </div>
        <div className="col-span-12 md:col-span-6 lg:col-span-4">
          <CACMetric />
        </div>
        <div className="col-span-12 md:col-span-6 lg:col-span-2">
          <LeadsProgress />
        </div>

        {/* Row 4: Facebook Demographics */}
        <div className="col-span-12 lg:col-span-6">
          <FacebookDemographics />
        </div>

        {/* Row 5: Sales Charts */}
        <div className="col-span-12 lg:col-span-6">
          <SalesTrendChart />
        </div>
        <div className="col-span-12 lg:col-span-6">
          <UnitsSoldChart />
        </div>

        {/* Row 6: Distribution Charts */}
        <div className="col-span-12 md:col-span-6 lg:col-span-4">
          <ProductDistributionChart />
        </div>
        <div className="col-span-12 md:col-span-6 lg:col-span-4">
          <CustomerSatisfactionChart />
        </div>
        <div className="col-span-12 md:col-span-6 lg:col-span-4">
          <DeliveryPerformanceChart />
        </div>

        {/* Row 7: Customer Acquisition */}
        <div className="col-span-12">
          <CustomerAcquisitionChart />
        </div>
      </div>

      <DashboardFooter />
    </div>
  )
}
